// Feito por Nico Ramos - GRR20210574

// Executa o estagio de inicializacao
void state_init();

// Executa o estagio de servir
void state_serve();

// Laco principal, executa o jogo
void state_play();

// Pausa o jogo e imprime um menu de ajuda
void state_help();

// Encerra o jogo
void state_close();

// Fim de uma partida, apresenta o score e pergunta se quer jogar novamente
void state_over();
